import {
  type Brand,
  type InsertBrand,
  type Product,
  type InsertProduct,
  type Review,
  type InsertReview,
  type SupportRequest,
  type InsertSupportRequest,
  type ProductWithBrand,
  type ProductWithDetails,
  type ServiceProvider,
  type InsertServiceProvider,
  type ServiceProviderReview,
  type InsertServiceProviderReview,
  type Notification,
  type Favorite,
  type ClientProfile,
  type InsertClientProfile,
  type User,
  type UpsertUser,
  brands,
  products,
  reviews,
  supportRequests,
  serviceProviders,
  clientProfile,
  users,
} from "@shared/schema";
import { randomUUID } from "crypto";
import { db } from "./db";
import { eq, like, and } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  // Brands
  getBrand(id: string): Promise<Brand | undefined>;
  getAllBrands(): Promise<Brand[]>;
  createBrand(brand: InsertBrand): Promise<Brand>;
  searchBrands(query: string): Promise<Brand[]>;

  // Products
  getProduct(id: string): Promise<Product | undefined>;
  getProductWithBrand(id: string): Promise<ProductWithBrand | undefined>;
  getProductWithDetails(id: string): Promise<ProductWithDetails | undefined>;
  getAllProducts(): Promise<ProductWithBrand[]>;
  getProductsByBrand(brandId: string): Promise<ProductWithBrand[]>;
  searchProducts(query: string): Promise<ProductWithBrand[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, product: Partial<Product>): Promise<Product | undefined>;
  deleteProduct(id: string): Promise<boolean>;

  // Reviews
  getReview(id: string): Promise<Review | undefined>;
  getReviewsByProduct(productId: string): Promise<Review[]>;
  getAllReviews(): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;

  // Support Requests
  getSupportRequest(id: string): Promise<SupportRequest | undefined>;
  getSupportRequestsByProduct(productId: string): Promise<SupportRequest[]>;
  getAllSupportRequests(): Promise<SupportRequest[]>;
  createSupportRequest(request: InsertSupportRequest): Promise<SupportRequest>;
  updateSupportRequest(id: string, request: Partial<SupportRequest>): Promise<SupportRequest | undefined>;

  // Service Providers
  getServiceProvider(id: string): Promise<ServiceProvider | undefined>;
  getAllServiceProviders(): Promise<ServiceProvider[]>;
  getServiceProvidersByDistrict(district: string): Promise<ServiceProvider[]>;
  createServiceProvider(provider: InsertServiceProvider): Promise<ServiceProvider>;
  updateServiceProvider(id: string, provider: Partial<ServiceProvider>): Promise<ServiceProvider | undefined>;
  deleteServiceProvider(id: string): Promise<boolean>;

  // Service Provider Reviews
  getServiceProviderReviews(providerId: string): Promise<ServiceProviderReview[]>;
  createServiceProviderReview(review: InsertServiceProviderReview): Promise<ServiceProviderReview>;
  getAverageRating(providerId: string): Promise<number>;

  // Notifications
  getNotificationsByProduct(productId: string): Promise<Notification[]>;
  createNotification(notification: Omit<Notification, 'id' | 'createdAt'>): Promise<Notification>;
  getAllUnsentNotifications(): Promise<Notification[]>;
  markNotificationAsSent(id: string): Promise<boolean>;

  // Favorites
  getFavoriteProducts(): Promise<string[]>;
  getFavoriteProviders(): Promise<string[]>;
  toggleFavorite(type: 'product' | 'provider', targetId: string): Promise<boolean>;
  isFavorite(type: 'product' | 'provider', targetId: string): Promise<boolean>;

  // Warranty Extensions
  addWarrantyExtension(id: string, extension: {
    extendedExpirationDate: Date;
    insuranceProvider: string;
    agentName: string;
    policyNumber: string;
    extensionCost?: number;
  }): Promise<Product | undefined>;

  // Client Profile
  getClientProfile(): Promise<ClientProfile | undefined>;
  saveClientProfile(profile: InsertClientProfile): Promise<ClientProfile>;
  updateClientProfile(profile: Partial<ClientProfile>): Promise<ClientProfile | undefined>;
}

// For development/testing
export interface UserForStorage extends User {
  createdAt: Date;
  updatedAt: Date;
}

export class MemStorage implements IStorage {
  private brands: Map<string, Brand>;
  private products: Map<string, Product>;
  private reviews: Map<string, Review>;
  private supportRequests: Map<string, SupportRequest>;
  private serviceProviders: Map<string, ServiceProvider>;
  private serviceProviderReviews: Map<string, ServiceProviderReview>;
  private notifications: Map<string, Notification>;
  private favorites: Map<string, Favorite>;
  private clientProfile: ClientProfile | null;
  private users: Map<string, UserForStorage>;

  constructor() {
    this.brands = new Map();
    this.products = new Map();
    this.reviews = new Map();
    this.supportRequests = new Map();
    this.serviceProviders = new Map();
    this.serviceProviderReviews = new Map();
    this.notifications = new Map();
    this.favorites = new Map();
    this.clientProfile = null;
    this.users = new Map();

    // Seed with some popular brands
    this.seedBrands();
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    const { createdAt, updatedAt, ...rest } = user;
    return rest;
  }

  async upsertUser(user: UpsertUser): Promise<User> {
    const now = new Date();
    const existing = this.users.get(user.id);
    
    const userForStorage: UserForStorage = {
      ...user,
      email: user.email || null,
      firstName: user.firstName || null,
      lastName: user.lastName || null,
      profileImageUrl: user.profileImageUrl || null,
      createdAt: existing?.createdAt || now,
      updatedAt: now,
    };
    
    this.users.set(user.id, userForStorage);
    const { createdAt, updatedAt, ...rest } = userForStorage;
    return rest as User;
  }

  private seedBrands() {
    const brands: InsertBrand[] = [
      {
        name: "Apple",
        supportEmail: "support@apple.com",
        supportPhone: "+1-800-692-7753",
        website: "https://www.apple.com/support/",
        category: "Informática",
      },
      {
        name: "Samsung",
        supportEmail: "support@samsung.com",
        supportPhone: "+351-808-207-267",
        website: "https://www.samsung.com/pt/support/",
        category: "Eletrodomésticos",
      },
      {
        name: "LG",
        supportEmail: "apoio.cliente@lge.com",
        supportPhone: "+351-707-505-454",
        website: "https://www.lg.com/pt/support",
        category: "Eletrodomésticos",
      },
      {
        name: "Sony",
        supportEmail: "info@sony.pt",
        supportPhone: "+351-707-780-785",
        website: "https://www.sony.pt/support",
        category: "Televisão e Áudio",
      },
      {
        name: "Bosch",
        supportEmail: "bshp.repacao@bshg.com",
        supportPhone: "+351-214-250-730",
        website: "https://www.bosch-home.pt/servico",
        category: "Eletrodomésticos",
      },
      {
        name: "Siemens",
        supportEmail: "siemens-pt@bshg.com",
        supportPhone: "+351-214-250-700",
        website: "https://www.siemens-home.bsh-group.com/pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Microsoft",
        supportEmail: "support@microsoft.com",
        supportPhone: "+351-21-366-5100",
        website: "https://support.microsoft.com/",
        category: "Informática",
      },
      {
        name: "Dell",
        supportEmail: "tech_support@dell.com",
        supportPhone: "+351-707-788-788",
        website: "https://www.dell.com/support/",
        category: "Informática",
      },
      {
        name: "HP",
        supportEmail: "support@hp.com",
        supportPhone: "+351-707-222-000",
        website: "https://support.hp.com/",
        category: "Informática",
      },
      {
        name: "Xiaomi",
        supportEmail: "service.pt@xiaomi.com",
        supportPhone: "+351-308-810-456",
        website: "https://www.mi.com/pt/service/",
        category: "Telefones",
      },
      {
        name: "Teka",
        supportEmail: "servico.cliente@teka.pt",
        supportPhone: "+351-256-200-100",
        website: "https://www.teka.pt/servico-tecnico/",
        category: "Eletrodomésticos",
      },
      {
        name: "Ariston",
        supportEmail: "info@ariston.pt",
        supportPhone: "+351-213-180-900",
        website: "https://www.ariston.com/pt-PT/",
        category: "Eletrodomésticos",
      },
      {
        name: "AEG",
        supportEmail: "rma.pt@eletrolux.com",
        supportPhone: "+351-210-304-261",
        website: "https://www.aeg.pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Avenzo",
        supportEmail: "sat@avenzo.biz",
        supportPhone: "+351-800-800-800",
        website: "https://www.avenzo.pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Beko",
        supportEmail: "servico.clientes@beko.pt",
        supportPhone: "+351-214-250-650",
        website: "https://www.beko.pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Bluesens",
        supportEmail: "posvenda@bluesens.com",
        supportPhone: "+351-226-108-030",
        website: "https://www.bluesens.com/",
        category: "Eletrodomésticos",
      },
      {
        name: "Candy",
        supportEmail: "service.portugal@candy-hoover.com",
        supportPhone: "+351-214-250-600",
        website: "https://www.candy.pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Hoover",
        supportEmail: "service.portugal@candy-hoover.com",
        supportPhone: "+351-214-250-600",
        website: "https://www.hoover.pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Haier",
        supportEmail: "service.pt@haier.com",
        supportPhone: "+351-214-250-500",
        website: "https://www.haier.pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Confortec",
        supportEmail: "geral@liana.com.pt",
        supportPhone: "+351-214-250-400",
        website: "https://www.confortec.pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Telefac",
        supportEmail: "geral@liana.com.pt",
        supportPhone: "+351-214-250-300",
        website: "https://www.telefac.pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Newpool",
        supportEmail: "geral@liana.com.pt",
        supportPhone: "+351-214-250-350",
        website: "https://www.newpool.pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Cata",
        supportEmail: "junis@junis.pt",
        supportPhone: "+34-938-521-818",
        website: "https://www.cata.com/pt-es/",
        category: "Eletrodomésticos",
      },
      {
        name: "Casio",
        supportEmail: "margaridadias@casio.pt",
        supportPhone: "+351-210-304-200",
        website: "https://www.casio-europe.com/pt/",
        category: "Eletrónicos",
      },
      {
        name: "Crown",
        supportEmail: "spv.crowneurope@gmail.com",
        supportPhone: "+351-214-250-200",
        website: "https://www.crown.pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Celly",
        supportEmail: "devoluciones@esprinet.com",
        supportPhone: "+351-214-250-150",
        website: "https://www.celly.pt/",
        category: "Eletrónicos",
      },
      {
        name: "Cecotec",
        supportEmail: "suporte@cecotec.pt",
        supportPhone: "+351-300-057-275",
        website: "https://www.cecotec.pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Delta",
        supportEmail: "clientes.retail@mydeltaq.com",
        supportPhone: "+351-214-250-050",
        website: "https://www.delta.pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Delba",
        supportEmail: "assistenciatecnica@sacrofil.pt",
        supportPhone: "+351-214-250-000",
        website: "https://www.delba.pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Daitsu",
        supportEmail: "geral@servitis.pt",
        supportPhone: "+351-214-250-500",
        website: "https://www.daitsu.pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Ufesa",
        supportEmail: "servicosat@ufesa.pt",
        supportPhone: "+351-214-250-750",
        website: "https://www.ufesa.es/?lang=pt-pt",
        category: "Eletrodomésticos",
      },
      {
        name: "Epson",
        supportEmail: "apoio_clientes@epson.pt",
        supportPhone: "+351-707-222-000",
        website: "https://www.epson.pt/pt_PT/support",
        category: "Impressoras e Periféricos",
      },
      {
        name: "eMachines",
        supportEmail: "support_pt@emachines.com",
        supportPhone: "+351-214-156-700",
        website: "https://www.emachines.com/ec/pt/PT/content/home.html",
        category: "Computadores",
      },
      {
        name: "e-star",
        supportEmail: "estar@atinformatica.pt",
        supportPhone: "+351-229-059-999",
        website: "https://www.atinformatica.pt/",
        category: "Computadores",
      },
      {
        name: "Fagor",
        supportEmail: "contacto@fagorelectrodomestico.com",
        supportPhone: "+351-707-502-207",
        website: "https://www.fagorelectrodomestico.pt/contactos",
        category: "Eletrodomésticos",
      },
      {
        name: "Electrolux",
        supportEmail: "electrolux.service@electrolux.pt",
        supportPhone: "+351-308-813-383",
        website: "https://www.electrolux.pt/support/contact-us/",
        category: "Eletrodomésticos",
      },
      {
        name: "Emtec",
        supportEmail: "support.emtec@dexxon.eu",
        supportPhone: "+33-147-291-900",
        website: "https://www.emtec-international.com/",
        category: "Produtos Tecnológicos",
      },
      {
        name: "Energizer",
        supportEmail: "geral@tametgroup.com",
        supportPhone: "+351-229-059-430",
        website: "https://energizer.com/eu/portugal/",
        category: "Baterias e Iluminação",
      },
      {
        name: "Energysytem",
        supportEmail: "garantias.telenets.es",
        supportPhone: "+34-934-110-700",
        website: "https://www.energysytem.es/",
        category: "Eletrónicos",
      },
      {
        name: "Flama",
        supportEmail: "sat@flama.pt",
        supportPhone: "+351-808-250-178",
        website: "https://www.flama.pt",
        category: "Eletrodomésticos",
      },
      {
        name: "Fujitsu",
        supportEmail: "portugal.helpdesk@ts.fujitsu.com",
        supportPhone: "+351-217-244-400",
        website: "https://www.fujitsu.com/pt/",
        category: "Computadores",
      },
      {
        name: "Growing",
        supportEmail: "geral@grow.com.pt",
        supportPhone: "+351-211-303-000",
        website: "https://www.grow.com.pt/",
        category: "Equipamentos Industriais",
      },
      {
        name: "Groundtec",
        supportEmail: "groundtec@groundtec.com.pt",
        supportPhone: "+351-227-133-368",
        website: "https://www.groundtec.com.pt/",
        category: "Equipamentos Construtivos",
      },
      {
        name: "Lovit",
        supportEmail: "lovit@lovit.com.pt",
        supportPhone: "+351-227-133-368",
        website: "https://www.lovit.com.pt/",
        category: "Equipamentos",
      },
      {
        name: "Grunkel",
        supportEmail: "repuestos@cointer.com",
        supportPhone: "+34-954-182-404",
        website: "https://grunkel.com",
        category: "Eletrónicos",
      },
      {
        name: "Hisense",
        supportEmail: "atencaoaocliente@hisenseiberia.com",
        supportPhone: "+351-800-181-818",
        website: "https://www.hisense.pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Hitachi",
        supportEmail: "contacto@hitachi.pt",
        supportPhone: "+351-212-199-900",
        website: "https://www.hitachi.eu/en/",
        category: "Eletrodomésticos",
      },
      {
        name: "Insys",
        supportEmail: "suporte.tecnico@insys.pt",
        supportPhone: "+351-234-340-880",
        website: "https://www.insys.pt/",
        category: "Computadores",
      },
      {
        name: "Indesit",
        supportEmail: "apoio@indesit.pt",
        supportPhone: "+351-219-406-200",
        website: "https://www.indesit.pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Ariston",
        supportEmail: "contacto@ariston.pt",
        supportPhone: "+351-219-605-300",
        website: "https://www.ariston.com/pt-pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Whirlpool",
        supportEmail: "apoio_consumidor@email.whirlpool.com",
        supportPhone: "+351-707-203-204",
        website: "https://www.whirlpool.pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Infiniton",
        supportEmail: "contacto@infiniton.pt",
        supportPhone: "+34-958-087-169",
        website: "https://infiniton.pt/",
        category: "Eletrónicos",
      },
      {
        name: "Jocca",
        supportEmail: "atencionalcliente@jocca.es",
        supportPhone: "+34-976-472-047",
        website: "https://www.joccashop.com/pt/",
        category: "Eletrónicos",
      },
      {
        name: "Kenwood",
        supportEmail: "contacto@kenwoodworld.com",
        supportPhone: "+351-707-201-468",
        website: "https://www.kenwoodworld.com/pt-pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "LG",
        supportEmail: "pt.cic@lge.com",
        supportPhone: "+351-300-600-033",
        website: "https://www.lg.com/pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Loewe",
        supportEmail: "customerservice@loewe.com",
        supportPhone: "+49-9261-99-500",
        website: "https://www.loewe.com/",
        category: "Eletrónicos",
      },
      {
        name: "Lenovo",
        supportEmail: "pt-support@lenovo.com",
        supportPhone: "+351-213-665-231",
        website: "https://www.lenovo.com/pt/pt/",
        category: "Computadores",
      },
      {
        name: "Manta",
        supportEmail: "contacto@manta.pt",
        supportPhone: "+351-300-000-000",
        website: "https://manta.pt/",
        category: "Eletrónicos",
      },
      {
        name: "Meireles",
        supportEmail: "contactos@meireles.pt",
        supportPhone: "+351-256-000-000",
        website: "https://www.meireles.pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Memup",
        supportEmail: "suporte@memup.pt",
        supportPhone: "+351-300-000-000",
        website: "https://memup.pt/",
        category: "Eletrónicos",
      },
      {
        name: "Maxcom",
        supportEmail: "obsluga.klienta@maxcom.pl",
        supportPhone: "+48-325-070-0",
        website: "https://pt.maxcommobile.eu/",
        category: "Telemóveis",
      },
      {
        name: "Neckar",
        supportEmail: "suporte@neckar.pt",
        supportPhone: "+351-300-000-000",
        website: "https://neckar.pt/",
        category: "Eletrónicos",
      },
      {
        name: "Nardi",
        supportEmail: "info@nardioutdoor.com",
        supportPhone: "+39-444-422-100",
        website: "https://www.nardioutdoor.com/",
        category: "Móveis",
      },
      {
        name: "Nintendo",
        supportEmail: "service@nintendo.de",
        supportPhone: "+351-211-129-511",
        website: "https://www.nintendo.com/pt-pt/",
        category: "Consolas",
      },
      {
        name: "NGS",
        supportEmail: "suporte@ngs.eu",
        supportPhone: "+351-300-000-000",
        website: "https://www.ngs.eu/pt/",
        category: "Eletrónicos",
      },
      {
        name: "Nilox",
        supportEmail: "suporte@nilox.pt",
        supportPhone: "+351-300-000-000",
        website: "https://nilox.pt/",
        category: "Eletrónicos",
      },
      {
        name: "Olympus",
        supportEmail: "pt.support@olympus.com",
        supportPhone: "+351-300-000-000",
        website: "https://www.olympus.pt/",
        category: "Câmaras",
      },
      {
        name: "Orima",
        supportEmail: "suporte@orima.pt",
        supportPhone: "+351-300-000-000",
        website: "https://orima.pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Philips",
        supportEmail: "apoio@philips.pt",
        supportPhone: "+351-800-780-903",
        website: "https://www.philips.pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Primux",
        supportEmail: "contacto@primux.es",
        supportPhone: "+34-988-120-120",
        website: "https://www.primux.es/",
        category: "Eletrónicos",
      },
      {
        name: "Prixton",
        supportEmail: "suporte@prixton.pt",
        supportPhone: "+351-300-000-000",
        website: "https://prixton.pt/",
        category: "Eletrónicos",
      },
      {
        name: "PlayStation",
        supportEmail: "suportederede@pt.playstation.com",
        supportPhone: "+351-211-121-813",
        website: "https://www.playstation.com/pt-pt/",
        category: "Consolas",
      },
      {
        name: "Rowenta",
        supportEmail: "apoio@rowenta.pt",
        supportPhone: "+351-214-237-700",
        website: "https://www.rowenta.pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "Remington",
        supportEmail: "apoio@remington.pt",
        supportPhone: "+351-800-100-058",
        website: "https://pt.remington-europe.com/",
        category: "Eletrónicos",
      },
      {
        name: "Russell Hobbs",
        supportEmail: "apoio@russellhobbs.pt",
        supportPhone: "+351-800-100-058",
        website: "https://pt.russellhobbs.com/",
        category: "Eletrodomésticos",
      },
      {
        name: "SPC",
        supportEmail: "support@spc.es",
        supportPhone: "+351-308-805-245",
        website: "https://www.spcstore.pt/",
        category: "Eletrónicos",
      },
      {
        name: "Samsung",
        supportEmail: "sep.contactus@samsung.com",
        supportPhone: "+351-210-608-098",
        website: "https://www.samsung.com/pt/",
        category: "Eletrodomésticos",
      },
      {
        name: "StreamSystem",
        supportEmail: "suporte@streamsystem.pt",
        supportPhone: "+351-300-000-000",
        website: "https://streamsystem.pt/",
        category: "Eletrónicos",
      },
      {
        name: "TomTom",
        supportEmail: "pt-support@tomtom.com",
        supportPhone: "+351-800-780-277",
        website: "https://www.tomtom.com/pt-pt/",
        category: "GPS",
      },
      {
        name: "TNB",
        supportEmail: "contacto@tnb.pt",
        supportPhone: "+351-707-917-070",
        website: "https://tnb.pt/",
        category: "Serviços",
      },
      {
        name: "Xbox",
        supportEmail: "support@xbox.com",
        supportPhone: "+351-800-209-175",
        website: "https://www.xbox.com/pt-pt/",
        category: "Consolas",
      },
      {
        name: "Xiaomi",
        supportEmail: "4you@tametgroup.com",
        supportPhone: "+351-229-964-100",
        website: "https://www.xiaomistore.pt/",
        category: "Telemóveis",
      },
      {
        name: "Toshiba",
        supportEmail: "suporte@toshiba.pt",
        supportPhone: "+351-707-266-266",
        website: "https://www.toshiba.eu/",
        category: "Eletrónicos",
      },
      {
        name: "SVAN",
        supportEmail: "info@svanelectro.com",
        supportPhone: "+351-300-305-065",
        website: "https://svanelectro.com/",
        category: "Eletrodomésticos",
      },
    ];

    brands.forEach((brand) => {
      const id = randomUUID();
      this.brands.set(id, { ...brand, id });
    });
  }

  // Brands
  async getBrand(id: string): Promise<Brand | undefined> {
    return this.brands.get(id);
  }

  async getAllBrands(): Promise<Brand[]> {
    return Array.from(this.brands.values()).sort((a, b) => a.name.localeCompare(b.name));
  }

  async createBrand(insertBrand: InsertBrand): Promise<Brand> {
    const id = randomUUID();
    const brand: Brand = { ...insertBrand, id };
    this.brands.set(id, brand);
    return brand;
  }

  async searchBrands(query: string): Promise<Brand[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.brands.values())
      .filter(brand => brand.name.toLowerCase().includes(lowerQuery) || 
                      brand.category.toLowerCase().includes(lowerQuery))
      .sort((a, b) => a.name.localeCompare(b.name));
  }

  // Products
  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductWithBrand(id: string): Promise<ProductWithBrand | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;

    const brand = await this.getBrand(product.brandId);
    if (!brand) return undefined;

    return { ...product, brand };
  }

  async getProductWithDetails(id: string): Promise<ProductWithDetails | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;

    const brand = await this.getBrand(product.brandId);
    if (!brand) return undefined;

    const reviews = await this.getReviewsByProduct(id);
    const supportRequests = await this.getSupportRequestsByProduct(id);

    return { ...product, brand, reviews, supportRequests };
  }

  async getAllProducts(): Promise<ProductWithBrand[]> {
    const products = Array.from(this.products.values());
    const productsWithBrands = await Promise.all(
      products.map(async (product) => {
        const brand = await this.getBrand(product.brandId);
        if (!brand) return null;
        return { ...product, brand };
      })
    );

    return productsWithBrands.filter((p): p is ProductWithBrand => p !== null)
      .sort((a, b) => new Date(b.purchaseDate).getTime() - new Date(a.purchaseDate).getTime());
  }

  async getProductsByBrand(brandId: string): Promise<ProductWithBrand[]> {
    const products = Array.from(this.products.values()).filter(p => p.brandId === brandId);
    const brand = await this.getBrand(brandId);
    if (!brand) return [];
    
    return products.map(p => ({ ...p, brand }))
      .sort((a, b) => new Date(b.purchaseDate).getTime() - new Date(a.purchaseDate).getTime());
  }

  async searchProducts(query: string): Promise<ProductWithBrand[]> {
    const lowerQuery = query.toLowerCase();
    const products = Array.from(this.products.values())
      .filter(p => p.name.toLowerCase().includes(lowerQuery) || 
                   p.model.toLowerCase().includes(lowerQuery));
    
    const productsWithBrands = await Promise.all(
      products.map(async (product) => {
        const brand = await this.getBrand(product.brandId);
        if (!brand) return null;
        return { ...product, brand };
      })
    );

    return productsWithBrands.filter((p): p is ProductWithBrand => p !== null)
      .sort((a, b) => new Date(b.purchaseDate).getTime() - new Date(a.purchaseDate).getTime());
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = randomUUID();
    
    // Calculate warranty expiration (3 years from purchase date in Europe)
    const purchaseDate = new Date(insertProduct.purchaseDate);
    const warrantyExpiration = new Date(purchaseDate);
    warrantyExpiration.setFullYear(warrantyExpiration.getFullYear() + 3);

    const product: Product = {
      ...insertProduct,
      id,
      purchaseDate,
      warrantyExpiration,
      photoUrls: insertProduct.photoUrls || [],
    };
    
    this.products.set(id, product);
    return product;
  }

  async updateProduct(id: string, updates: Partial<Product>): Promise<Product | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;

    const updated = { ...product, ...updates };
    this.products.set(id, updated);
    return updated;
  }

  async deleteProduct(id: string): Promise<boolean> {
    // Delete associated reviews and support requests
    const reviews = await this.getReviewsByProduct(id);
    reviews.forEach(review => this.reviews.delete(review.id));

    const supportRequests = await this.getSupportRequestsByProduct(id);
    supportRequests.forEach(request => this.supportRequests.delete(request.id));

    return this.products.delete(id);
  }

  async addWarrantyExtension(
    id: string,
    extension: {
      extendedExpirationDate: Date;
      insuranceProvider: string;
      agentName: string;
      policyNumber: string;
      extensionCost?: number;
    }
  ): Promise<Product | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;

    const updated: Product = {
      ...product,
      hasExtension: true,
      extendedExpirationDate: extension.extendedExpirationDate,
      insuranceProvider: extension.insuranceProvider,
      agentName: extension.agentName,
      policyNumber: extension.policyNumber,
      extensionCost: extension.extensionCost || 0,
      warrantyExpiration: extension.extendedExpirationDate,
    };
    this.products.set(id, updated);
    return updated;
  }

  // Reviews
  async getReview(id: string): Promise<Review | undefined> {
    return this.reviews.get(id);
  }

  async getReviewsByProduct(productId: string): Promise<Review[]> {
    return Array.from(this.reviews.values())
      .filter(review => review.productId === productId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getAllReviews(): Promise<Review[]> {
    return Array.from(this.reviews.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createReview(insertReview: InsertReview): Promise<Review> {
    const id = randomUUID();
    const review: Review = {
      ...insertReview,
      id,
      createdAt: new Date(),
      pros: insertReview.pros || [],
      cons: insertReview.cons || [],
    };
    this.reviews.set(id, review);
    return review;
  }

  // Support Requests
  async getSupportRequest(id: string): Promise<SupportRequest | undefined> {
    return this.supportRequests.get(id);
  }

  async getSupportRequestsByProduct(productId: string): Promise<SupportRequest[]> {
    return Array.from(this.supportRequests.values())
      .filter(request => request.productId === productId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getAllSupportRequests(): Promise<SupportRequest[]> {
    return Array.from(this.supportRequests.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createSupportRequest(insertRequest: InsertSupportRequest): Promise<SupportRequest> {
    const id = randomUUID();
    const supportRequest: SupportRequest = {
      ...insertRequest,
      id,
      status: "sent",
      emailSentAt: new Date(),
      createdAt: new Date(),
    };
    this.supportRequests.set(id, supportRequest);
    return supportRequest;
  }

  async updateSupportRequest(id: string, updates: Partial<SupportRequest>): Promise<SupportRequest | undefined> {
    const request = this.supportRequests.get(id);
    if (!request) return undefined;

    const updated = { ...request, ...updates };
    this.supportRequests.set(id, updated);
    return updated;
  }

  // Service Providers
  async getServiceProvider(id: string): Promise<ServiceProvider | undefined> {
    return this.serviceProviders.get(id);
  }

  async getAllServiceProviders(): Promise<ServiceProvider[]> {
    return Array.from(this.serviceProviders.values())
      .sort((a, b) => (b.averageRating || 0) - (a.averageRating || 0));
  }

  async getServiceProvidersByDistrict(district: string): Promise<ServiceProvider[]> {
    return Array.from(this.serviceProviders.values())
      .filter(p => p.district.toLowerCase() === district.toLowerCase())
      .sort((a, b) => (b.averageRating || 0) - (a.averageRating || 0));
  }

  async createServiceProvider(insertProvider: InsertServiceProvider): Promise<ServiceProvider> {
    const id = randomUUID();
    const provider: ServiceProvider = {
      ...insertProvider,
      id,
      supportedBrands: insertProvider.supportedBrands || [],
      averageRating: 0,
      createdAt: new Date(),
    };
    this.serviceProviders.set(id, provider);
    return provider;
  }

  async updateServiceProvider(id: string, updates: Partial<ServiceProvider>): Promise<ServiceProvider | undefined> {
    const provider = this.serviceProviders.get(id);
    if (!provider) return undefined;

    const updated = { ...provider, ...updates };
    this.serviceProviders.set(id, updated);
    return updated;
  }

  async deleteServiceProvider(id: string): Promise<boolean> {
    // Delete reviews
    const reviews = Array.from(this.serviceProviderReviews.values())
      .filter(r => r.providerId === id);
    reviews.forEach(r => this.serviceProviderReviews.delete(r.id));

    return this.serviceProviders.delete(id);
  }

  // Service Provider Reviews
  async getServiceProviderReviews(providerId: string): Promise<ServiceProviderReview[]> {
    return Array.from(this.serviceProviderReviews.values())
      .filter(r => r.providerId === providerId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createServiceProviderReview(insertReview: InsertServiceProviderReview): Promise<ServiceProviderReview> {
    const id = randomUUID();
    const review: ServiceProviderReview = {
      ...insertReview,
      id,
      createdAt: new Date(),
    };
    this.serviceProviderReviews.set(id, review);

    // Update provider's average rating
    const avgRating = await this.getAverageRating(insertReview.providerId);
    await this.updateServiceProvider(insertReview.providerId, { averageRating: Math.round(avgRating) });

    return review;
  }

  async getAverageRating(providerId: string): Promise<number> {
    const reviews = await this.getServiceProviderReviews(providerId);
    if (reviews.length === 0) return 0;
    const sum = reviews.reduce((acc, r) => acc + r.rating, 0);
    return sum / reviews.length;
  }

  // Notifications
  async getNotificationsByProduct(productId: string): Promise<Notification[]> {
    return Array.from(this.notifications.values())
      .filter(n => n.productId === productId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createNotification(notification: Omit<Notification, 'id' | 'createdAt'>): Promise<Notification> {
    const id = randomUUID();
    const newNotification: Notification = {
      ...notification,
      id,
      createdAt: new Date(),
    };
    this.notifications.set(id, newNotification);
    return newNotification;
  }

  async getAllUnsentNotifications(): Promise<Notification[]> {
    return Array.from(this.notifications.values())
      .filter(n => !n.sent)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  }

  async markNotificationAsSent(id: string): Promise<boolean> {
    const notification = this.notifications.get(id);
    if (!notification) return false;

    notification.sent = true;
    notification.sentAt = new Date();
    this.notifications.set(id, notification);
    return true;
  }

  // Favorites
  async getFavoriteProducts(): Promise<string[]> {
    return Array.from(this.favorites.values())
      .filter(f => f.type === 'product')
      .map(f => f.targetId);
  }

  async getFavoriteProviders(): Promise<string[]> {
    return Array.from(this.favorites.values())
      .filter(f => f.type === 'provider')
      .map(f => f.targetId);
  }

  async toggleFavorite(type: 'product' | 'provider', targetId: string): Promise<boolean> {
    const key = `${type}-${targetId}`;
    const exists = Array.from(this.favorites.values()).some(
      f => f.type === type && f.targetId === targetId
    );

    if (exists) {
      // Remove favorite
      const toDelete = Array.from(this.favorites.entries()).find(
        ([_, f]) => f.type === type && f.targetId === targetId
      );
      if (toDelete) {
        this.favorites.delete(toDelete[0]);
      }
      return false;
    } else {
      // Add favorite
      const id = randomUUID();
      this.favorites.set(id, {
        id,
        type,
        targetId,
        createdAt: new Date(),
      });
      return true;
    }
  }

  async isFavorite(type: 'product' | 'provider', targetId: string): Promise<boolean> {
    return Array.from(this.favorites.values()).some(
      f => f.type === type && f.targetId === targetId
    );
  }

  // Client Profile
  async getClientProfile(): Promise<ClientProfile | undefined> {
    return this.clientProfile || undefined;
  }

  async saveClientProfile(profile: InsertClientProfile): Promise<ClientProfile> {
    const id = randomUUID();
    const now = new Date();
    const clientProf: ClientProfile = {
      ...profile,
      id,
      createdAt: now,
      updatedAt: now,
    };
    this.clientProfile = clientProf;
    return clientProf;
  }

  async updateClientProfile(profile: Partial<ClientProfile>): Promise<ClientProfile | undefined> {
    if (!this.clientProfile) return undefined;
    
    const updated: ClientProfile = {
      ...this.clientProfile,
      ...profile,
      updatedAt: new Date(),
    };
    this.clientProfile = updated;
    return updated;
  }
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0] as User | undefined;
  }

  async upsertUser(user: UpsertUser): Promise<User> {
    const existing = await this.getUser(user.id);
    if (existing) {
      await db.update(users).set(user).where(eq(users.id, user.id));
      return (await this.getUser(user.id))!;
    }
    await db.insert(users).values(user);
    return (await this.getUser(user.id))!;
  }

  // Brands
  async getBrand(id: string): Promise<Brand | undefined> {
    const result = await db.select().from(brands).where(eq(brands.id, id));
    return result[0] as Brand | undefined;
  }

  async getAllBrands(): Promise<Brand[]> {
    return await db.select().from(brands);
  }

  async createBrand(brand: InsertBrand): Promise<Brand> {
    const result = await db.insert(brands).values(brand).returning();
    return result[0] as Brand;
  }

  async searchBrands(query: string): Promise<Brand[]> {
    return await db.select().from(brands)
      .where(like(brands.name, `%${query}%`));
  }

  // Products
  async getProduct(id: string): Promise<Product | undefined> {
    const result = await db.select().from(products).where(eq(products.id, id));
    return result[0] as Product | undefined;
  }

  async getProductWithBrand(id: string): Promise<ProductWithBrand | undefined> {
    const result = await db.select().from(products)
      .innerJoin(brands, eq(products.brandId, brands.id))
      .where(eq(products.id, id));
    if (!result[0]) return undefined;
    const { products: p, brands: b } = result[0];
    return { ...p, brand: b } as ProductWithBrand;
  }

  async getProductWithDetails(id: string): Promise<ProductWithDetails | undefined> {
    const product = await this.getProductWithBrand(id);
    if (!product) return undefined;
    const revs = await this.getReviewsByProduct(id);
    const reqs = await this.getSupportRequestsByProduct(id);
    return { ...product, reviews: revs, supportRequests: reqs } as ProductWithDetails;
  }

  async getAllProducts(): Promise<ProductWithBrand[]> {
    const results = await db.select().from(products)
      .innerJoin(brands, eq(products.brandId, brands.id));
    return results.map(({ products: p, brands: b }) => ({ ...p, brand: b }) as ProductWithBrand);
  }

  async getProductsByBrand(brandId: string): Promise<ProductWithBrand[]> {
    const results = await db.select().from(products)
      .innerJoin(brands, eq(products.brandId, brands.id))
      .where(eq(products.brandId, brandId));
    return results.map(({ products: p, brands: b }) => ({ ...p, brand: b }) as ProductWithBrand);
  }

  async searchProducts(query: string): Promise<ProductWithBrand[]> {
    const results = await db.select().from(products)
      .innerJoin(brands, eq(products.brandId, brands.id))
      .where(like(products.name, `%${query}%`));
    return results.map(({ products: p, brands: b }) => ({ ...p, brand: b }) as ProductWithBrand);
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const result = await db.insert(products).values(product).returning();
    return result[0] as Product;
  }

  async updateProduct(id: string, product: Partial<Product>): Promise<Product | undefined> {
    await db.update(products).set(product).where(eq(products.id, id));
    return await this.getProduct(id);
  }

  async deleteProduct(id: string): Promise<boolean> {
    const result = await db.delete(products).where(eq(products.id, id));
    return true;
  }

  // Reviews
  async getReview(id: string): Promise<Review | undefined> {
    const result = await db.select().from(reviews).where(eq(reviews.id, id));
    return result[0] as Review | undefined;
  }

  async getReviewsByProduct(productId: string): Promise<Review[]> {
    return await db.select().from(reviews).where(eq(reviews.productId, productId));
  }

  async getAllReviews(): Promise<Review[]> {
    return await db.select().from(reviews);
  }

  async createReview(review: InsertReview): Promise<Review> {
    const result = await db.insert(reviews).values(review).returning();
    return result[0] as Review;
  }

  // Support Requests
  async getSupportRequest(id: string): Promise<SupportRequest | undefined> {
    const result = await db.select().from(supportRequests).where(eq(supportRequests.id, id));
    return result[0] as SupportRequest | undefined;
  }

  async getSupportRequestsByProduct(productId: string): Promise<SupportRequest[]> {
    return await db.select().from(supportRequests).where(eq(supportRequests.productId, productId));
  }

  async getAllSupportRequests(): Promise<SupportRequest[]> {
    return await db.select().from(supportRequests);
  }

  async createSupportRequest(request: InsertSupportRequest): Promise<SupportRequest> {
    const result = await db.insert(supportRequests).values(request).returning();
    return result[0] as SupportRequest;
  }

  // Service Providers
  async getServiceProvider(id: string): Promise<ServiceProvider | undefined> {
    const result = await db.select().from(serviceProviders).where(eq(serviceProviders.id, id));
    return result[0] as ServiceProvider | undefined;
  }

  async getAllServiceProviders(): Promise<ServiceProvider[]> {
    return await db.select().from(serviceProviders);
  }

  async searchServiceProviders(query: string): Promise<ServiceProvider[]> {
    return await db.select().from(serviceProviders)
      .where(like(serviceProviders.name, `%${query}%`));
  }

  async createServiceProvider(provider: InsertServiceProvider): Promise<ServiceProvider> {
    const result = await db.insert(serviceProviders).values(provider).returning();
    return result[0] as ServiceProvider;
  }

  // Service Provider Reviews
  async getServiceProviderReview(id: string): Promise<ServiceProviderReview | undefined> {
    const result = await db.select().from(serviceProviders).where(eq(serviceProviders.id, id));
    return result[0] as ServiceProviderReview | undefined;
  }

  async getServiceProviderReviewsByProvider(providerId: string): Promise<ServiceProviderReview[]> {
    const result = await db.select().from(serviceProviders).where(eq(serviceProviders.id, providerId));
    return [];
  }

  async createServiceProviderReview(review: InsertServiceProviderReview): Promise<ServiceProviderReview> {
    return review as ServiceProviderReview;
  }

  // Notifications
  async getNotification(id: string): Promise<Notification | undefined> {
    return undefined;
  }

  async getAllNotifications(): Promise<Notification[]> {
    return [];
  }

  async createNotification(notification: Omit<Notification, 'id' | 'createdAt'>): Promise<Notification> {
    const id = randomUUID();
    const notif: Notification = { ...notification, id, createdAt: new Date() };
    return notif;
  }

  // Favorites
  async toggleFavorite(type: 'product' | 'provider', targetId: string): Promise<boolean> {
    return true;
  }

  async isFavorite(type: 'product' | 'provider', targetId: string): Promise<boolean> {
    return false;
  }

  // Client Profile
  async getClientProfile(): Promise<ClientProfile | undefined> {
    const result = await db.select().from(clientProfile);
    return result[0] as ClientProfile | undefined;
  }

  async saveClientProfile(profile: InsertClientProfile): Promise<ClientProfile> {
    const result = await db.insert(clientProfile).values(profile).returning();
    return result[0] as ClientProfile;
  }

  async updateClientProfile(profile: Partial<ClientProfile>): Promise<ClientProfile | undefined> {
    const current = await this.getClientProfile();
    if (!current) return undefined;
    const updated = { ...current, ...profile, updatedAt: new Date() };
    await db.update(clientProfile).set(updated);
    return updated as ClientProfile;
  }
}

export const storage = new DatabaseStorage();
